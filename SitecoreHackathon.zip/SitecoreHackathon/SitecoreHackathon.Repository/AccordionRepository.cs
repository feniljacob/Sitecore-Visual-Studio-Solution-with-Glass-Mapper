﻿using System;
using Glass.Mapper.Sc;
using SitecoreHackathon.Contracts.Interfaces;
using SitecoreHackathon.Framework.Helper;
using SitecoreHackathon.Model;

namespace SitecoreHackathon.Repository
{
    /// <summary>
    /// Accordion Repository.
    /// </summary>
    public class AccordionContract : IAccordionContract
    {

        /// <summary>
        /// 
        /// </summary>
        private readonly ISitecoreContext _sitecoreContext;
      
        /// <summary>
        /// ArticleDataContract Constructor
        /// </summary>
        /// <param name="context"></param>
        /// <param name="logger"></param>
        public AccordionContract(ISitecoreContext context)
        {
            this._sitecoreContext = context;
       }

        /// <summary>
        /// Get Carousel.
        /// </summary>
        /// <param name="dataSource">parameter for data.</param>
        /// <returns>Carousel item.</returns>
        public IAccordionModel GetFaqs(string dataSource)
        {
            try
            {
                var faqItems = _sitecoreContext.GetItem<IAccordionModel>(dataSource);
                return faqItems;
            }
            catch (ArgumentNullException ex)
            {
                Logger.Write("AccordionContract " + "GetAccordion " + ex.Message);
                throw;
            }
        }
    }
}
