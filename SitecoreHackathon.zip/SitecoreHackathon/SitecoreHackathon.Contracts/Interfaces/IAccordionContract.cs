﻿using SitecoreHackathon.Model;

namespace SitecoreHackathon.Contracts.Interfaces
{
    /// <summary>
    /// IAccordionContract Definition.
    /// </summary>
    public interface IAccordionContract
    {
        /// <summary>
        /// GetCarousel method definition.
        /// </summary>
        /// <param name="dataSource">Data Parameter.</param>
        /// <returns>Return Carousel.</returns>
        IAccordionModel GetFaqs(string dataSource);
    }
}
