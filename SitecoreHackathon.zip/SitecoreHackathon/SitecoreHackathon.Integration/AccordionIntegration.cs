﻿
using System;
using SitecoreHackathon.Contracts.Interfaces;
using SitecoreHackathon.Integration.IntegrationContracts;
using SitecoreHackathon.Model;

namespace SitecoreHackathon.Integration
{
    public class AccordionIntegration:IAccordionIntegration
    {
         #region "Declaration"
       /// <summary>
       /// 
       /// </summary>
        private readonly IAccordionContract _accordionContract;
        #endregion

        /// <summary>
        /// 
        /// </summary>
        /// <param name="accordionItems"></param>
        public AccordionIntegration(IAccordionContract accordionItems)
        {
            this._accordionContract = accordionItems;
        }

        public IAccordionModel GetFaqs(string dataSource)
        {
            return this._accordionContract.GetFaqs(dataSource);
        }

    }
}
