﻿using SitecoreHackathon.Model;

namespace SitecoreHackathon.Integration.IntegrationContracts
{
    public interface IAccordionIntegration
    {
        /// <summary>
        /// Get Accordion FAQs items
        /// </summary>
        /// <param name="dataSource">Data Parameter.</param>
        /// <returns>Return Carousel.</returns>
        IAccordionModel GetFaqs(string dataSource);
    }
}
