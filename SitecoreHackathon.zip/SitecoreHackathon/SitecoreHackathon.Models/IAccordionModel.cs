﻿namespace SitecoreHackathon.Model
{ 
    /// <summary>
    /// IAccordion interface inherits IGenericItem.
    /// </summary>
    public interface IAccordionModel 
    {
   /// <summary>
        /// Gets or sets a value indicating whether the item is enabled.
        /// </summary>
        /// <value>Object Return.</value>
        string FixedHeight
        {
            get;
            set;
        }
      
    }
}
