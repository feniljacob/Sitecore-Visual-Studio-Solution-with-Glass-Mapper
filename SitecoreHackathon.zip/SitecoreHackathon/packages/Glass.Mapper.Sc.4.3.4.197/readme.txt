

/*******************************/

Glass.Mapper.Sc V4

/*******************************/

Thank you for downloading Glass.Mapper.Sc V4, this is the latest and greatest version of Glass.Mapper.Sc.

//TODO: CHECK THE FOLLOWING!!!

* Does your project contain a reference to Glass.Mapper.Sc.dll? If this reference is missing Glass was unable to find the Sitecore.Kernel.dll 
reference in your project. Add a reference to Sitecore.Kernel.dll and re-install the Glass.Mapper.Sc nuget package.
*  Does your project contain a reference to Glass.Mapper.Sc,Mvc.dll? If this reference is missing Glass was unable to find the System.Web.Mvc.dll 
reference in your project. Add a reference to System.Web.Mvc.dll and re-install the Glass.Mapper.Sc nuget package. You only need to do this if 
you want MVC support with Glass.* 



For more information on how to use the framework please visit http://www.glass.lu/Mapper/Sc

Glass.Mapper.Sc is distributed under the Apache License 2.0 https://github.com/mikeedwards83/Glass.Mapper/blob/master/License.txt

You can stay up to date with Glass.Mapper.Sc by signing up to receive our newsletter http://www.glass.lu/Signup

We automatically generate a website contain help information which you can read at http://docs.glass.lu

We have a great community who will help answer your questions at http://stackoverflow.com/ but if you need more 
specialist support please contact us at hello@glass.lu where we will be able to offer our consultancy services.



