﻿namespace Glass.Mapper.Maps
{
    public interface IMapProvider
    {
        IGlassMap[] Maps { get; }
    }
}