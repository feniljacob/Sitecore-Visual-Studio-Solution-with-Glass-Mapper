﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Glass.Mapper.Pipelines.ObjectConstruction.Tasks.Diagnostics
{
    public class ModelRequestedTask : AbstractObjectConstructionTask
    {

        public ModelRequestedTask()
        {
            base.Name = "ModelRequestedTask";
        }
    }
}
