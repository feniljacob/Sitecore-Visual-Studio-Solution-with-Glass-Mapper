﻿namespace SitecoreHackathon.Framework.Constants
{
    public static class Constants
    {

    }
}
