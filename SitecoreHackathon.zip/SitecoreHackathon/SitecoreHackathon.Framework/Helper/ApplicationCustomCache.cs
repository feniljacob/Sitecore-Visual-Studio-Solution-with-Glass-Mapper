﻿using Sitecore.Caching;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SitecoreHackathon.Framework.Helper
{
    public class ApplicationCustomCache : Sitecore.Caching.CustomCache
    {
        public ApplicationCustomCache(string name, long maxSize)
            : base(name, maxSize)
        {

        }

        new public void SetString(string key, string value)
        {
            base.SetString(key, value);
        }

        new public string GetString(string key)
        {
            return base.GetString(key);
        }

        public object GetObject(string key)
        {
            return base.GetObject(key);
        }

        new public void SetObject(string key, ICacheable value)
        {
            base.SetObject(key, value);
        }

        new public void Clear()
        {
            base.Clear();
        }

    }
}
