﻿using System;
using System.Collections.Generic;
using System.Linq;
using Sitecore.Diagnostics;

namespace SitecoreHackathon.Framework.Helper
{
   public static class Logger
    {
        /// <summary>
        /// Static Logger Class write method.
        /// </summary>
        /// <param name="message">To log</param>
        public static void Write(string message)
        {
            Log.Info(message, typeof(Logger));
        }
    }
}
