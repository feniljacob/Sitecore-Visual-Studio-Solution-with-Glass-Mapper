﻿using System;
using System.Web;

namespace SitecoreHackathon.Framework.Helper
{
    public static class ErrorHelper
    {

        /// <summary>
        /// Handle Application Exception
        /// 
        /// </summary>
        /// <param name="exception"></param>
        /// <param name="sender"></param>
        public static void HandleApplicationException(Exception exception, object sender)
        {
          ////return to asp.net error page in case of CustomErrorsMode.Off | IsDebugging
          ExceptionLogger(exception.Message, exception);
        }

      
        /// <summary>
        /// Exception Logger
        /// </summary>
        /// <param name="errorMessage"></param>
        /// <param name="exception"></param>
        private static void ExceptionLogger(string errorMessage, Exception exception)
        {
            Logger.Write(errorMessage + exception);

            if (HttpContext.Current != null)
            {
                HttpContext.Current.Server.ClearError();
            }
        }
    }
}
