﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Sitecore;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.ComputedFields;
using Sitecore.Data.Items;

using Sitecore.Data;


namespace SitecoreHackathon.Framework.Helper
{
    public class ComputedFields:IComputedIndexField
    {
        public object ComputeFieldValue(IIndexable indexable)
        {
            Item item = indexable as SitecoreIndexableItem;
            if (item == null)
                return null;
            if (item.TemplateName.Contains("Page"))
            {
                return GetIndexField(item);
            }
            return null;
        }

        public string FieldName { get; set; }
        public string ReturnType { get; set; }

        private StringBuilder GetIndexField(Item tagItem)
        {
            var myStringBuilder = new StringBuilder();
         
            if (tagItem.TemplateName.Contains("Page"))
            {
               //ToDo
            }

            return myStringBuilder;
        }
    }
}