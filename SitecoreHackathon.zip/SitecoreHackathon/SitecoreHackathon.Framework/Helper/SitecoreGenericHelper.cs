﻿using Sitecore;
using Sitecore.Configuration;
using Sitecore.Data;
using Sitecore.Data.Items;

//[assembly: CLSCompliant(true)]
namespace SitecoreHackathon.Framework.Helper
{
    public static class SitecoreGenericHelper
    {
        /// <summary>
        /// Gets the current Database.
        /// </summary>
        public static Database ContextDatabase => Context.ContentDatabase ?? Context.Database ?? Factory.GetDatabase("master");
        /// <summary>
        ///To get sitecore Item By Item path and curent sitecore context DB.
        /// </summary>
        /// <param name="path">Path of item</param>
        /// <param name="currentDb">sitecore context DB</param>
        /// <returns>SC Item</returns>
        public static Item GetItem(string path, Database currentDb)
        {
            Item item = currentDb.GetItem(path, Sitecore.Context.Language);

            return item != null && item.Versions.Count > 0 ? item : null;
        }
       
    }
}
