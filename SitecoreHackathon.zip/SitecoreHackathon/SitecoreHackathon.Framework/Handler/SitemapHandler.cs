﻿using System;
using System.Web;

namespace SitecoreHackathon.Framework.Handler
{
    public class HackathonHandler : IHttpHandler
    {
        public bool IsReusable
        {
            get
            {
                throw new NotImplementedException();
            }
        }

        public void ProcessRequest(HttpContext context)
        {
            throw new NotImplementedException();
        }
    }
}
