﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SitecoreHackathon.Web.Controllers
{
    public class HackathonController : BaseController
    {
        // GET: Hackathon
        public ActionResult Display()
        {
            return View("~/Views/Hackathon/Index.cshtml");
        }
    }
}