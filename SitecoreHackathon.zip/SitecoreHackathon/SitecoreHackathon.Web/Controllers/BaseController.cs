﻿using Glass.Mapper.Sc.Web.Mvc;
using SitecoreHackathon.Framework.Helper;

namespace SitecoreHackathon.Web.Controllers
{
    public class BaseController : GlassController
    {
        
        #region "Constructors"
        /// <summary>
        /// BaseController
        /// </summary>
        public BaseController()
        {

        }

        #endregion

        public void Log(string controllerName, string actionName, string message)
        {
            Logger.Write("Controller Name:" + controllerName + " Action Name:"+" Error Message:" + message);
        }
    }
}
