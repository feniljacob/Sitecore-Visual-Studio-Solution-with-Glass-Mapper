﻿using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using SitecoreHackathon.Framework.Helper;

namespace SitecoreHackathon.Web
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BootStrap.ConfigureDependency();
            MvcHandler.DisableMvcResponseHeader = true; 
        }
        public void Application_End()
        {

        }
        protected void Application_BeginRequest()
        {
        }

        /// <summary>
        /// Handling Application Error
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args">app. event argument</param>
        //public void Application_Error(object sender, EventArgs args)
        //{
        //    try
        //    {
        //        Exception exception = Server.GetLastError();
        //        ErrorHelper.HandleApplicationException(exception, sender);
        //    }
        //    catch
        //    {
        //        HttpContext.Current.ClearError();
        //        return;
        //    }
        //}
    }
}