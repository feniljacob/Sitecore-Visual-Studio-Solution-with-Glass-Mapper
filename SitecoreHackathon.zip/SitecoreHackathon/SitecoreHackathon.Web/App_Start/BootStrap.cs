﻿using Autofac.Integration.Wcf;
using SitecoreHackathon.Contracts.Interfaces;
using SitecoreHackathon.Integration.IntegrationContracts;
using SitecoreHackathon.Repository;

namespace SitecoreHackathon.Web
{
    #region "Using Namespaces"
    using System.Reflection;
    using System.Web.Mvc;
    using Autofac;
    using Autofac.Integration.Mvc;
    using Glass.Mapper.Sc;

    #endregion

    public class BootStrap
    {
        public static void ConfigureDependency()
        {

            var bootstrap = new BootStrap();
            ContainerBuilder builder = bootstrap.ConfigureContainer();
            //Service realted Autofac registrtion - Start
            AutofacHostFactory.Container = builder.Build();
            DependencyResolver.SetResolver(new AutofacDependencyResolver(AutofacHostFactory.Container));

        }

        protected virtual ContainerBuilder ConfigureContainer()
        {

            var builder = new ContainerBuilder();
            builder.RegisterControllers(Assembly.GetExecutingAssembly());
            builder.RegisterType<SitecoreHackathon.Integration.AccordionIntegration>().As<IAccordionIntegration>().SingleInstance();
            builder.RegisterType<SitecoreContext>().As<ISitecoreContext>().SingleInstance();
            builder.RegisterType<AccordionContract>().As<IAccordionContract>().SingleInstance();
           return builder;
        }
    }
}